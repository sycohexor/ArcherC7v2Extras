Note:	Please do verify if you have the correct firmware version for your device, flashing the incorrect firmware might break it
	It is also not recommended to flash the router over wireless

This firmware version has the bootloader removed, this means that 131584 bytes have been chopped of from the beginning of the firmware file (and thus leaving only the firmware)
This firmware version is for the TP-LINK Archer-C7 V2

If you are on OpenWrt or Gargoyle and want to go back to stock firmware, either flash the file named Archer-C7-V2-FW0.0.3-stripped.bin trough the web interface
or if the web interface is not availlable, transfer the Archer-C7-V2-FW0.0.3-stripped.bin file to the /tmp directory of the router via ssh (e.g. winscp)
and issue the following command:   sysupgrade /tmp/Archer-C7-V2-FW0.0.3-stripped.bin   via the ssh terminal (e.g. putty)
If you can't access via ssh see: http://wiki.openwrt.org/doc/howto/firstlogin#login.with.telnet for more information

Of course this firmware maybe can be flashed over other custom firmwares out there, but check there documentation to be sure on how to do it correctly

The file md5sum.txt contains a md5sum that can be used to verify the Archer-C7-V2-FW0.0.3-stripped.bin file


-theFriedZombie
www.friedzombie.com

firmware derived from: ArcherC7v2_en_3_14_2_up_boot(150304).bin
